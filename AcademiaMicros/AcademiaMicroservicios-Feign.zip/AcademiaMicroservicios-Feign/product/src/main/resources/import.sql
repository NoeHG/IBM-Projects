INSERT INTO products (name, price) VALUES ('Phone', 1000);
INSERT INTO products (name, price) VALUES ('Pc', 2000);
INSERT INTO products (name, price) VALUES ('Monitor', 1500);