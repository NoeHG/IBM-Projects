import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-page',
  imports: [],
  templateUrl: './custom-page.component.html',
})
export default class CustomPageComponent {}
