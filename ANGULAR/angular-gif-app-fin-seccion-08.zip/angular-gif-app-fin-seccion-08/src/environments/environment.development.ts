export const environment = {
  production: true,
  companyName: 'Gifs',
  companyName2: 'App',
  companySlogan: 'Maneja tus gifs',

  // ApiKeys
  // https://developers.giphy.com/dashboard/
  giphyApiKey: 'gk94aLGrTB1kEtWBy5P8FgpPsc4Shusf',
  giphyUrl: 'https://api.giphy.com/v1',
};
