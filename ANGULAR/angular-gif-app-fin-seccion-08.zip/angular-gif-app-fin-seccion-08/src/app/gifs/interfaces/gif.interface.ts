export interface Gif {
  id: string;
  title: string;
  url: string;
}
