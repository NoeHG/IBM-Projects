# GifsApp

Este un proyecto de Angular.

## Dev

1. Clonar el repositorio
2. Instalar las dependencias con `npm install`
3. Iniciar el servidor con `ng serve`
4. Navegar a `http://localhost:4200/`
